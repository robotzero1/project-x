const path = require(`path`)
const slugify = require('slugify')
const { createFilePath } = require(`gatsby-source-filesystem`);

exports.onCreateNode = ({ node, actions }) => {
  const { createNodeField } = actions
  if (node.internal.type === `MysqlOfferCats`) {
    console.log(node.category_name)

    createNodeField({
      node,
      name: `slug`,
      value: slugify(node.category_name, {lower: true}),
    })``
  }  
  if (node.internal.type === `MysqlOffers`) {
    console.log(node.offer_title)
    createNodeField({
      node,
      name: `slug`,
      value: slugify(node.offer_title, {lower: true}),
    })
  }

}
 

exports.createPages = async ({ graphql, actions }) => {
  // **Note:** The graphql function call returns a Promise
  // see: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise for more info
  const { createPage } = actions
  const result = await graphql(`
    query {
      allMysqlOfferCats(filter: { category_active: { eq: 1 } }) {
        edges {
          node {
            fields {
              slug
            }
            id_category
          }
        }
      },

    }
  `)

   // Pages containing a list of offers in one category
  result.data.allMysqlOfferCats.edges.forEach(({ node }) => {
    console.log(node)
    createPage({
      path: node.fields.slug,
      component: path.resolve(`./src/templates/template-offers.js`),
      context: {
        // Data passed to context is available
        // in page queries as GraphQL variables.
        slug: node.fields.slug,
        categoryID: node.id_category,
      },
    })
  })
/*
  // This 
  result.data.allMysqlOffers.edges.forEach(({ node }) => {
    createPage({
      path: node.fields.slug,
      component: path.resolve(`./src/templates/template-offer.js`),
      context: {
        // Data passed to context is available
        // in page queries as GraphQL variables.
        slug: node.fields.slug,
      },
    })
  }) */


}
