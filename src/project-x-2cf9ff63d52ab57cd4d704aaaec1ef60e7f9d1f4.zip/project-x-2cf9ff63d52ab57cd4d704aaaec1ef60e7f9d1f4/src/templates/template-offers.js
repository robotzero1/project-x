// Step 1: Import React. This lets you use JSX inside your .js file.
import * as React from "react";
import { Link, graphql } from "gatsby";
import { GatsbyImage, getImage } from "gatsby-plugin-image";
import Layout from "../components/layout";

/* Step 2: Define your component/page. Note that your
component name should start with a capital letter. */
const Offers = ({ data }) => {
  const category = data.category;
  const offers = data.offers;
  const categoryImage = getImage(category.mysqlImage);

  return (
    <Layout>
      <GatsbyImage image={categoryImage} alt={category.category_name} />  
      <h1>Offers in Category</h1>
      <div>
        {offers.edges.map(({ node }, index) => (
          <div key={index}>
            <Link to={"/" + node.fields.slug}>
              <GatsbyImage image={node.mysqlImage.childImageSharp.gatsbyImageData} alt={node.offer_title} />
              <div>{node.offer_title}</div>
              <div>{node.offer_desc}</div>
            </Link>
          </div>
        ))}
      </div>
    </Layout>
  );
};

export const query = graphql`
  query ($categoryID: Int!) {
    category: mysqlOfferCats(  category_active: { eq: 1 }, id_category: { eq: $categoryID }  ) {
      category_name
      mysqlImage {
        childImageSharp {
          gatsbyImageData(
            width: 600
            placeholder: BLURRED
            formats: [AUTO, WEBP, AVIF]
          )
        }
      }
    }
    offers: allMysqlOffers(
      filter: { offer_active: { eq: 1 }, category_id: { eq: $categoryID } } ) {
      edges {
        node {
          offer_title
          offer_desc
          mysqlImage {
            childImageSharp {
              gatsbyImageData(
                width: 200
                placeholder: BLURRED
                formats: [AUTO, WEBP, AVIF]
              )
            }
          }
          fields {
            slug
          }
        }
      }
    }
  }
`;

/* Step 3: Export your component so it
can be used by other parts of your app. */
export default Offers;
