// Step 1: Import React. This lets you use JSX inside your .js file.
import * as React from "react";
import { graphql } from "gatsby";
import { StaticImage  } from "gatsby-plugin-image";
import Layout from "../components/layout";
import NightStatus from "../components/night-status";
import NightRequest from "../components/night-request";

const ClubNight = ({ data }) => {
  // console.log(data)
  const night = data.night;
  const club = data.club;
  // const clubImage = getImage(club.mysqlImage);
  return (
    <Layout>
      <h1>Club Night Details</h1>
      <div>
        <div>
          <StaticImage src="../images/r8.png" alt="A dinosaur" />
          <div>CLUB NIGHT: {night.club_night_name}</div>
          <div>{night.club_night_description}</div>
          <div>Club: {club.venue_name}</div> 
          <div>&nbsp;</div>

          <div><NightStatus nightID={night.id_club_night}/></div>
        </div>
      </div>
    </Layout>
  );
};

export const query = graphql`
  query ($nightID: Int!, $venueID: Int!) {
    night: mysqlClubNights(club_night_active: { eq: 1 }, id_club_night: { eq: $nightID }) {
      id_club_night
      club_night_name
      club_night_description
    }
    club: mysqlClubs(venue_active: { eq: 1 }, id_venue: { eq: $venueID }) {
      venue_name
    }
  }
`;

/* Step 3: Export your component so it
can be used by other parts of your app. */
export default ClubNight;
