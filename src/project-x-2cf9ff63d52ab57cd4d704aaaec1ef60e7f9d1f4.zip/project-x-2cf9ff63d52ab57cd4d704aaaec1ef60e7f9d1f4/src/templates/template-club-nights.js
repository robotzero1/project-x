// Step 1: Import React. This lets you use JSX inside your .js file.
import * as React from "react";
import { Link, graphql } from "gatsby";
import { GatsbyImage, getImage } from "gatsby-plugin-image";
import Layout from "../components/layout";

/* Step 2: Define your component/page. Note that your
component name should start with a capital letter. */
const ClubNights = ({ data }) => {
  const club = data.club;
  const nights = data.nights;
  const clubImage = getImage(club.mysqlImage);
  return (
    <Layout>
        <GatsbyImage image={clubImage} alt={club.venue_name} /> 
      <h1>Nights in Venue</h1>
      <div>
        {nights.edges.map(({ node }, index) => (
          <div key={index}>
            <Link to={"/" + node.fields.slug}>
              <div>{node.club_night_name}</div>

              <div>---------------</div>
            </Link>
          </div>
        ))}
      </div>
    </Layout>
  );
};

export const query = graphql`
  query ($clubID: Int!) {
    club: mysqlClubs( venue_active: { eq: 1 }  id_venue: { eq: $clubID } ) {
      venue_name
      mysqlImage {
        childImageSharp {
          gatsbyImageData(
            width: 600
            placeholder: BLURRED
            formats: [AUTO, WEBP, AVIF]
          )
        }
      }
    }

    nights: allMysqlClubNights( filter: { club_night_active: { eq: 1 } club_night_venue_id: { eq: $clubID }  } ) {
      edges {
        node {
          club_night_name
          fields {
            slug
          }
        }
      }
    }
  }
`;

/* Step 3: Export your component so it
can be used by other parts of your app. */
export default ClubNights;
