// Step 1: Import React. This lets you use JSX inside your .js file.
import * as React from "react";
import { graphql } from "gatsby";
import { GatsbyImage, getImage } from "gatsby-plugin-image";
import Layout from "../components/layout";

const Offer = ({ data }) => {
  const offer = data.offer;
  const venue = data.venue;
  const offerImage = getImage(offer.mysqlImage);
  const venueImage = getImage(venue.mysqlImage);
  return (
    <Layout>
      <h1>Offer Detail</h1>
      Venue: {venue.venue_name}
      <GatsbyImage image={venueImage} alt={venue.venue_name} />
      <div>
        <div>
          <GatsbyImage image={offerImage} alt={offer.offer_title} />

          <div>OFFER:</div>
          <div>{offer.offer_title}</div>
          <div>{offer.offer_desc}</div>
        </div>
      </div>
    </Layout>
  );
};

export const query = graphql`
  query ($offerID: Int!, $venueID: Int!) {
    offer: mysqlOffers(offer_active: { eq: 1 }, id_offer: { eq: $offerID }) {
      offer_title
      offer_desc
      mysqlImage {
        childImageSharp {
          gatsbyImageData(
            width: 200
            placeholder: BLURRED
            formats: [AUTO, WEBP, AVIF]
          )
        }
      }
    }
    venue: mysqlVenues(venue_active: { eq: 1 }, id_venue: { eq: $venueID }) {
      venue_name
      mysqlImage {
        childImageSharp {
          gatsbyImageData(
            width: 400
            placeholder: BLURRED
            formats: [AUTO, WEBP, AVIF]
          )
        }
      }
    }
  }
`;

/* Step 3: Export your component so it
can be used by other parts of your app. */
export default Offer;
