export const isBrowser = () => typeof window !== "undefined";

export const getUser = () =>
  isBrowser() && window.localStorage.getItem("gatsbyUser")
    ? JSON.parse(window.localStorage.getItem("gatsbyUser"))
    : {};

const setUser = (user) =>
  window.localStorage.setItem("gatsbyUser", JSON.stringify(user));

export const handleLogin = ({ inputuser, inputpass }) => {
  const myRequest = new Request(
    "https://fintastic.co.uk/belocal/member/account.php",
    {
      method: "POST",
      mode: "cors",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        inputuser: inputuser,
        inputpass: inputpass,
      }),
    }
  );

  fetch(myRequest)
    .then(handleErrors)
    .then((response) => response.json())
    .then((data) => {
      if (data.hasOwnProperty("error")) {
        showFailedMessage(data.error);
      } else {
        handleLoginSuccess(data);
      }
      console.log(data);
    })
    .catch((error) => console.log(error));
    
  return false;
};

function handleErrors(response) {
  if (!response.ok) {
    throw Error(response.statusText);
  }
  return response;
}

const showFailedMessage = (message) => {
  const messageArea = document.querySelector("#messagebox");
  messageArea.style.display = "block";
  messageArea.style.backgroundColor = "pink";
  messageArea.textContent = message;
};

const handleLoginSuccess = (data) => {
  setUser({
    id: data.id,
    name: data.name,
    expiry: data.expiry,
  });
  const messageArea = document.querySelector("#messagebox");
  messageArea.style.display = "block";
  messageArea.style.backgroundColor = "green";
  messageArea.textContent = "Logged in succesfully";
};

export const isLoggedIn = () => {
  const user = getUser();

  return !!user.name;
};

export const logout = (callback) => {
  setUser({});
  callback();
};
