// Step 1: Import React. This lets you use JSX inside your .js file.
import * as React from "react";
import { Link, graphql } from "gatsby";
import { GatsbyImage } from "gatsby-plugin-image";
import Layout from "../components/layout";

/* Step 2: Define your component/page. Note that your
component name should start with a capital letter. */
const Clubs = ({ data }) => {
  return (
    <Layout>
      <h1>Clubs</h1>
      <div>
        {data.allMysqlClubs.edges.map(({ node }, index) => (
          <div key={index}>
            <Link to={"/" + node.fields.slug}>
              <GatsbyImage
                image={node.mysqlImage.childImageSharp.gatsbyImageData}
                alt={node.venue_name}
              />

              <div>
                <b>{node.venue_name}</b>
              </div>
              <div>{node.venue_description}</div>
            </Link>
            <div>&nbsp;</div>
            <div>&nbsp;</div>
            <div>&nbsp;</div>
          </div>
        ))}
      </div>
    </Layout>
  );
};

export const query = graphql`
  {
    allMysqlClubs(filter: { venue_active: { eq: 1 } }) {
      edges {
        node {
          venue_name
          venue_description
          mysqlImage {
            childImageSharp {
              gatsbyImageData(
                width: 600
                aspectRatio: 2.5
                placeholder: BLURRED
                formats: [AUTO, WEBP, AVIF]
              )
            }
          }
          fields {
            slug
          }
        }
      }
    }
  }
`;

/* Step 3: Export your component so it
can be used by other parts of your app. */
export default Clubs;
