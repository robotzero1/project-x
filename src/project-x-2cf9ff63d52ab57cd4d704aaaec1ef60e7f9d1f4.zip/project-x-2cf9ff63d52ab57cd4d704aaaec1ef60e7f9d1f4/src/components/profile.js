import React from "react";
import { getUser } from "../services/auth";
import ListStatus from "./list-status";

const Profile = () => (
  <>
    <h1>Your profile</h1>
    <ul>
      <li>Name: {getUser().name}</li>
      <li>id: {getUser().id}</li>
    </ul>
    <h2>List Status</h2>
    <p className="list-status-container"><ListStatus /></p>
  </>
);

export default Profile;
