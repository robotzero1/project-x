import React, { useState, useEffect } from "react";
import { CardElement, useStripe, useElements } from "@stripe/react-stripe-js";

const CheckoutForm = () => {
  const [succeeded, setSucceeded] = useState(false);
  const [error, setError] = useState(null);
  const [processing, setProcessing] = useState("");
  const [disabled, setDisabled] = useState(true);
  const [clientSecret, setClientSecret] = useState("");
  const [paymentIntentId, setPaymentIntentId] = useState("");
  const [paymentStatus, setPaymentStatus] = useState("");
  const [pendingStatus, setpendingStatus] = useState("");
  const [conpleteStatus, setCompleteStatus] = useState("");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [pass, setPass] = useState("");
  const stripe = useStripe();
  const elements = useElements();

  // Add to pending...
  const handleJoinPending = () => {
    const myRequest = new Request(
      "https://fintastic.co.uk/belocal/member/stripe-join.php",
      {
        method: "POST",
        mode: "cors",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          inputmembername: name,
          inputmemberemail: email,
          inputmemberpass: pass,
          paymentintentid: paymentIntentId,          
        }),
      }
    );

    fetch(myRequest)
      .then(handleErrors)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data.hasOwnProperty("error")) {
          console.log(data.error);
        } else {
            console.log("Creating account...")
            setpendingStatus("Creating account...");
            const checkMemberTable = setInterval(() => {
                console.log('check for completion');
                checkJoinSuccess(checkMemberTable);
              }, 10000);
        }
      })
      .catch((error) => console.log(error));

    return false;
  };

    // final step to create user in database
    const checkJoinSuccess = (checkMemberTable) => {
        const myRequest = new Request(
          "https://fintastic.co.uk/belocal/member/stripe-join.php",
          {
            method: "POST",
            mode: "cors",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              inputmembername: name,
              inputmemberemail: email,
              inputmemberpass: pass,
              paymentintentid: paymentIntentId,          
            }),
          }
        );
    
        fetch(myRequest)
          .then(handleErrors)
          .then((response) => response.json())
          .then((data) => {
            console.log(data);
            if (data.hasOwnProperty("error")) {
              console.log(data.error);
            }
            if (data.hasOwnProperty("status")){
                console.log(data.status)
                if (data.status == 'complete'){
                    setCompleteStatus("Account Created. Please log in above.");
                    clearInterval(checkMemberTable)
                }

            }
          })
          .catch((error) => console.log(error));
    
        return false;
      };

  function handleErrors(response) {
    if (!response.ok) {
      throw Error(response.statusText);
    }
    return response;
  }

  useEffect(() => {
    // Create PaymentIntent as soon as the page loads
    window
      .fetch("https://fintastic.co.uk/belocal/member/stripe-create.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ items: [{ id: "xl-tshirt" }] }),
      })
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        console.log(data);
        setClientSecret(data.clientSecret);
        setPaymentIntentId(data.paymentIntentId);
      });
  }, []);

  const cardStyle = {
    style: {
      base: {
        color: "#32325d",
        fontFamily: "Arial, sans-serif",
        fontSmoothing: "antialiased",
        fontSize: "16px",
        "::placeholder": {
          color: "#32325d",
        },
      },
      invalid: {
        color: "#fa755a",
        iconColor: "#fa755a",
      },
    },
  };

  const handleChange = async (event) => {
    // Listen for changes in the CardElement
    // and display any errors as the customer types their card details
    setDisabled(event.empty);
    setError(event.error ? event.error.message : "");
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    setProcessing(true);

    const payload = await stripe.confirmCardPayment(clientSecret, {
      receipt_email: email,
      payment_method: {
        card: elements.getElement(CardElement),
        billing_details: {
          name: name,
          email: email,
        },
      },
    });

    if (payload.error) {
      setError(`Payment failed ${payload.error.message}`);
      setProcessing(false);
    } else {
      setError(null);
      setProcessing(false);
      setPaymentStatus("Payment success");
      setSucceeded(true);
      handleJoinPending();      
    }
  };

  return (
    <form id="payment-form" onSubmit={handleSubmit}>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Full Name"
      />
      <input
        type="text"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Your email address"
      />
      <input
        type="text"
        value={pass}
        onChange={(e) => setPass(e.target.value)}
        placeholder="Create a password"
      />

      <CardElement
        id="card-element"
        options={cardStyle}
        onChange={handleChange}
      />
      <button disabled={processing || disabled || succeeded} id="submit">
        <span id="button-text">
          {processing ? (
            <div className="spinner" id="spinner"></div>
          ) : (
            "Pay now"
          )}
        </span>
      </button>
      {/* Show any error that happens when processing the payment */}
      {error && (
        <div className="card-error" role="alert">
          {error}
        </div>
      )}
      {/* Show a success message upon completion */}
      <div>{paymentStatus}</div>
      <div>{pendingStatus}</div>
      <div>{conpleteStatus}</div>
    </form>
  );
};
export default CheckoutForm;
