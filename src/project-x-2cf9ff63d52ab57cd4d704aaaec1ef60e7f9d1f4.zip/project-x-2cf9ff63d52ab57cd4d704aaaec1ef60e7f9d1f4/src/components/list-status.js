import React from "react";
import { useEffect, useState } from "react";
import { getUser } from "../services/auth";

const ListStatus = () => {
  const [listsStatus, setlistsStatus] = useState(null);

  const handleErrors = (response) => {
    if (!response.ok) {
      throw Error(response.statusText);
    }
    return response;
  };

  const showFailedMessage = (message) => {
    const messageArea = document.querySelector(".list-status-container");
    const messageInner = document.createElement("div");
    messageInner.style.backgroundColor = "pink";
    messageArea.appendChild(messageInner).innerHTML = message;
  };

  const myRequest = new Request(
    "https://fintastic.co.uk/belocal/member/list-status.php",
    {
      method: "POST",
      mode: "cors",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        user: getUser().id,
      }),
    }
  );

  useEffect(() => {
    fetch(myRequest)
      .then(handleErrors)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data.hasOwnProperty("error")) {
          showFailedMessage(data.error);
        } else {
          setlistsStatus(data);
        }
      })
      .catch((error) => console.log(error));
  }, []);

  return (
    <>
      {listsStatus?.map((node, index) => (
        <div key={index}>
          {node.club_night_name} - 
          {node.club_night_day} - 
          {node.venue_name} - 
          {node.list_member_status}
          <div>&nbsp;</div>
        </div>
      ))}
    </>
  );
};

export default ListStatus;
