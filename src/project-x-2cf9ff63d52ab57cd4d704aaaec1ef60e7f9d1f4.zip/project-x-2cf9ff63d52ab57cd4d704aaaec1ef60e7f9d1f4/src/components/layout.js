import * as React from 'react'
import { Link } from 'gatsby'
import NavBar from './nav-bar'
import "@fontsource/poppins" // Defaults to weight 400.
import "@fontsource/poppins/100.css" // Defaults to weight 400.
import {
  container,
  heading,
  navLinks,
  navLinkItem,
  navLinkText,
} from './layout.module.css'


const Layout = ({ pageTitle, children }) => {
  return (
    <main className={container}>
      <NavBar />
      <title>{pageTitle}</title>
      <nav>
        <ul className={navLinks}>
          <li className={navLinkItem}>
            <Link to="/" className={navLinkText}>
              Home
            </Link>
          </li>
          <li className={navLinkItem}>
            <Link to="/join-from-card" className={navLinkText}>
              Join from Card
            </Link>
          </li>
          <li className={navLinkItem}>
            <Link to="/join-from-stripe" className={navLinkText}>
              Join via Stripe
            </Link>
          </li>                    
          <li className={navLinkItem}>
            <Link to="/categories" className={navLinkText}>
              Offer Categories
            </Link>
          </li>
          <li className={navLinkItem}>
            <Link to="/clubs" className={navLinkText}>
              Clubs
            </Link>
          </li>          
        </ul>
      </nav>
      <h1 className={heading}>{pageTitle}</h1>

      {children}

    </main>
  )
}

export default Layout