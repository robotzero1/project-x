import React from "react";
import { useEffect, useState } from "react";
import { getUser } from "../services/auth";

const NightStatus = ({ nightID }) => {
  console.log(nightID);

  const [status, setStatus] = useState(null);
  const [buttonStatus, setbuttonStatus] = useState(null);

  const handleErrors = (response) => {
    if (!response.ok) {
      throw Error(response.statusText);
    }
    return response;
  };

  const showFailedMessage = (message) => {
    console.log(message);
    // const messageArea = document.querySelector(".list-status-container");
    // const messageInner = document.createElement("div");
    // messageInner.style.backgroundColor = "pink";
    // messageArea.appendChild(messageInner).innerHTML = message;
  };

  const updateList = () => {
    fetch("https://fintastic.co.uk/belocal/member/night-request.php", {
      method: "POST",
      mode: "cors",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        user: getUser().id,
        night: nightID,
      }),
    })
      .then(handleErrors)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data.hasOwnProperty("error")) {
          showFailedMessage(data.error);
        }
        if (data.hasOwnProperty("status")) {
          if (data.status == "deleted") {
            setbuttonStatus("REQUEST ENTRY");
          }
          if (data.status == "created") {
            setbuttonStatus("CANCEL ENTRY");
          }
        }
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    fetch("https://fintastic.co.uk/belocal/member/night-status.php", {
      method: "POST",
      mode: "cors",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        user: getUser().id,
        night: nightID,
      }),
    })
      .then(handleErrors)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data.hasOwnProperty("error")) {
          showFailedMessage(data.error);
          if (data.error == "No request record found") {
            setbuttonStatus("REQUEST ENTRY");
            setStatus(null);
          }
        } else {
          setStatus(data);
          setbuttonStatus("CANCEL ENTRY");
        }
      })
      .catch((error) => console.log(error));
  }, [buttonStatus]);

  return (
    <>
      <div>{status?.list_member_status}</div>
      <div>
        <button onClick={() => updateList()}>{buttonStatus}</button>
      </div>
    </>
  );
};

export default NightStatus;
