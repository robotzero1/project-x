module.exports = {
  siteMetadata: {
    title: "projectX",
  },
  plugins: [
    `gatsby-plugin-image`,
    `gatsby-plugin-sharp`,
    `gatsby-transformer-sharp`, // Needed for dynamic images
    `gatsby-plugin-gatsby-cloud`,
    {
      resolve: `gatsby-source-filesystem`,
      options: {
        name: `images`,
        path: `${__dirname}/src/images`,
      },
    },
    {
      resolve: "gatsby-plugin-react-svg",
      options: {
        rule: {
          include: "/images/svg/"
        },
      },
    },
    {
      resolve: `gatsby-source-mysql`,
      options: {
        connectionDetails: {
          host: "209.124.66.21",
          user: "fintastic_uza",
          password: "5QlV0)d@ucWZ",
          database: "fintastic_blocal",
        },
        queries: [
          {
            statement: 'SELECT * FROM venues WHERE venue_type = "club"',
            idFieldName: "id_venue",
            name: "clubs",
            remoteImageFieldNames: ["venue_photo_ref"],
          },
          {
            statement: "SELECT * FROM club_nights",
            idFieldName: "id_club_night",
            name: "club_nights",
          },
          {
            statement: 'SELECT * FROM venues WHERE venue_type != "club"',
            idFieldName: "id_venue",
            name: "venues",
            remoteImageFieldNames: ["venue_photo_ref"],
          },          
          {
            statement: "SELECT * FROM offer_categories",
            idFieldName: "id_category",
            name: "offer_cats",
            remoteImageFieldNames: ["category_photo_ref"],
          },
          {
            statement: "SELECT * FROM offers",
            idFieldName: "id_offer",
            name: "offers",
            remoteImageFieldNames: ["offer_photo_ref"],
          },          
        ],
      },
    },
  ],
};
